# mypackage
This library was created as as example of how to publish a python package. 